-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 10, 2022 at 12:44 PM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coba_ukk`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `ambilMasakan`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ambilMasakan` ()  begin
select * from masakan;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `detail_pesanan`
--

DROP TABLE IF EXISTS `detail_pesanan`;
CREATE TABLE IF NOT EXISTS `detail_pesanan` (
  `id_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_pesanan` int(11) NOT NULL,
  `id_masakan` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL,
  `keterangan` text COMMENT 'seperti cabe ne di akhei',
  `status` enum('dimasak','matang') NOT NULL DEFAULT 'dimasak',
  PRIMARY KEY (`id_detail`),
  KEY `id_pesanan` (`id_pesanan`),
  KEY `id_masakan` (`id_masakan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `masakan`
--

DROP TABLE IF EXISTS `masakan`;
CREATE TABLE IF NOT EXISTS `masakan` (
  `id_masakan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_masakan` varchar(50) NOT NULL,
  `type` enum('makanan','minuman') NOT NULL,
  `status_masakan` enum('tersedia','habis') NOT NULL,
  `harga` int(11) NOT NULL,
  `act` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0 => tdk aktif,, 1 => active',
  PRIMARY KEY (`id_masakan`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masakan`
--

INSERT INTO `masakan` (`id_masakan`, `nama_masakan`, `type`, `status_masakan`, `harga`, `act`) VALUES
(1, 'Kentang Goreng', 'makanan', 'habis', 10000, '1'),
(2, 'Kopi Susu', 'minuman', 'tersedia', 7000, '1'),
(4, 'Roti Bakar', 'makanan', 'tersedia', 12500, '1'),
(5, 'Pisang Goreng', 'makanan', 'tersedia', 5000, '1'),
(6, 'Es Teh', 'minuman', 'tersedia', 3000, '1'),
(7, 'Es Jeruk ', 'minuman', 'tersedia', 4000, '1'),
(9, 'Nasi Goreng', 'makanan', 'tersedia', 15000, '1'),
(10, 'Mie Goreng', 'makanan', 'tersedia', 9000, '1');

-- --------------------------------------------------------

--
-- Table structure for table `meja`
--

DROP TABLE IF EXISTS `meja`;
CREATE TABLE IF NOT EXISTS `meja` (
  `id_meja` int(11) NOT NULL AUTO_INCREMENT,
  `no_meja` varchar(10) NOT NULL,
  `status_meja` enum('kosong','penuh') NOT NULL DEFAULT 'kosong',
  `act` enum('0','1') NOT NULL DEFAULT '1' COMMENT '1 => aktif , 0 => tdk',
  PRIMARY KEY (`id_meja`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meja`
--

INSERT INTO `meja` (`id_meja`, `no_meja`, `status_meja`, `act`) VALUES
(1, '01', 'kosong', '1'),
(2, '02', 'penuh', '1'),
(3, '03', 'kosong', '1'),
(4, '04', 'kosong', '1'),
(5, '05', 'kosong', '1'),
(7, '06', 'penuh', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

DROP TABLE IF EXISTS `pesanan`;
CREATE TABLE IF NOT EXISTS `pesanan` (
  `id_pesanan` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_pesanan` date NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_meja` int(11) DEFAULT NULL,
  `nama_masakan` varchar(20) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  PRIMARY KEY (`id_pesanan`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `tgl_pesanan`, `id_user`, `id_meja`, `nama_masakan`, `jumlah`, `total_harga`) VALUES
(1, '2022-03-17', 5, 1, 'Kentang Goreng', 3, 30000),
(10, '2022-03-19', 5, 5, 'Kentang Goreng', 1, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` enum('admin','kasir','waiter','owner') NOT NULL,
  `act` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0 => user terhapus/tdk aktif\r\n1 => user masih aktif',
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `password`, `level`, `act`) VALUES
(1, 'budi', 'budi', 'budi', 'admin', '1'),
(2, 'yani', 'yani', 'yani', 'admin', '1'),
(5, 'kuncoro', 'kuncoro', 'kuncoro', 'kasir', '1'),
(6, 'miramar', 'miramar', 'miramar', 'owner', '1'),
(7, 'rosalia', 'rosalia', 'rosalia', 'kasir', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
