<?php

// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
include 'config.php';

// menangkap data yang dikirim dari form login
$username = $_POST['username'];
$password = $_POST['password'];


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"SELECT * FROM user WHERE username='$username' and password='$password'");

$data = mysqli_fetch_assoc($login);

// var_dump($data);
// die();

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){

 // cek jika user login sebagai admin
 if($data['level']=="admin"){

  // buat session login dan username
  $_SESSION['username'] = $username;
  $_SESSION['level'] = "admin";
  $_SESSION['id_user'] = $data['id_user'];
  // alihkan ke halaman dashboard admin
  header("location:dashmin/dashboard.php");

 // cek jika user login sebagai pegawai
 }else if($data['level']=="kasir"){
  // buat session login dan username
  $_SESSION['username'] = $username;
  $_SESSION['level'] = "kasir";
  $_SESSION['id_user'] = $data['id_user'];
  // alihkan ke halaman dashboard pegawai
  header("location:dashmin/kasir/dashboardkasir.php");

}else if($data['level']=="owner"){
    // buat session login dan username
    $_SESSION['username'] = $username;
    $_SESSION['level'] = "owner";
    // alihkan ke halaman dashboard pegawai
    header("location:dashmin/owner/dashboardowner.php");

 }else{

  // alihkan ke halaman login kembali
  header("location:index.php?pesan=gagal");
 } 
}else{
 header("location:index.php?pesan=gagal");
}

?>