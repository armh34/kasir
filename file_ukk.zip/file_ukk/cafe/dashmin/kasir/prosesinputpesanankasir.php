
<?php
// Start the session
session_start();

$servername = "localhost";
$usernamedb = "root";
$passworddb = "";
$dbname = "coba_ukk";

//--filter input
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}



// define variables and set to empty values
if ($_SERVER["REQUEST_METHOD"] == "POST")  {
    // var_dump($_POST); die;
    $tgl_pesanan = test_input($_POST["tgl_pesanan"]);
    $id_user = test_input($_POST["id_user"]);
    $id_meja = test_input($_POST["id_meja"]);
    $nama_masakan = test_input($_POST["nama_masakan"]);
    $jumlah = test_input($_POST["jumlah"]);
    // $total_harga = test_input($_POST["total_harga"]);
    

    if ($tgl_pesanan  != '' and $id_user != '') {

        // Create connection
        $koneksi = new mysqli($servername, $usernamedb, $passworddb, $dbname);
        // Check connection
        if ($koneksi->connect_error) {
            die("Connection failed: " . $koneksi->connect_error);
        }
        $sql = "SELECT * FROM pesanan
        INNER JOIN masakan ON pesanan.nama_masakan = masakan.nama_masakan"; 
        
                        $result = $koneksi->query($sql);
                        $datamasakan = $result->fetch_assoc();
                        $hargamasakan = $datamasakan['harga'];
                        $total_harga = $jumlah * $hargamasakan; 
        $sql = "INSERT INTO pesanan (tgl_pesanan, id_user, id_meja, nama_masakan, jumlah, total_harga)
        VALUES ('$tgl_pesanan', '$id_user', '$id_meja', '$nama_masakan', '$jumlah', '$total_harga')";

        if (mysqli_query($koneksi, $sql)) {
            header('location:pesanankasir.php');
            
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
        }
        $koneksi->close();
    }
}
