<?php 
// koneksi database
include '../../config.php';
 
// menangkap data id yang di kirim dari url
$id = $_GET['id'];

$sql = "DELETE FROM masakan where id_masakan=$id";

if(
    $koneksi->query($sql) === TRUE){
        echo 'alert("Hapus Data Berhasil !!")';
        header('location:../masakan.php');
}else{
    echo "Error Deleting Record: " . $koneksi->error;
}
?>