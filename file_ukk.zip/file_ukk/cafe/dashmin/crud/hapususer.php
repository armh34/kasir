<?php
    $servername = "localhost";
    $usernamedb = "root";
    $passworddb = "";
    $dbname = "coba_ukk";

    // Create connection
    $koneksi = new mysqli($servername, $usernamedb, $passworddb, $dbname);
    // Check connection
    if ($koneksi->connect_error) {
        die("Connection failed: " . $koneksi->connect_error);
    }

    $id = $_GET['id'];

        // sql to delete a record
        $sql = "DELETE FROM user WHERE id_user='$id'";

        if ($koneksi->query($sql) === TRUE) {
            echo 'alert("Hapus data berhasil")';
            header('location:../user.php');
        } else {
            echo "Error deleting record: " . $koneksi->error;
        }
    