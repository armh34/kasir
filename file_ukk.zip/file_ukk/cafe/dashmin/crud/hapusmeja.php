<?php 
// koneksi database
include '../../config.php';
 
// menangkap data id yang di kirim dari url
$id = $_GET['id'];

$sql = "DELETE FROM meja where id_meja=$id";

if(
    $koneksi->query($sql) === TRUE){
        echo 'alert("Hapus Data Berhasil !!")';
        header('location:../meja.php');
}else{
    echo "Error Deleting Record: " . $koneksi->error;
}
?>