<?php
// Start the session
session_start();

$servername = "localhost";
$usernamedb = "root";
$passworddb = "";
$dbname = "coba_ukk";

//--filter input
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//var_dump(isset($_POST['proses']));die;

// define variables and set to empty values

if (isset($_POST['proses'])) {
    //var_dump("oke");die;
    $id_meja = test_input($_POST["id_meja"]);
    $no_meja = test_input($_POST["no_meja"]);
    $status_meja = test_input($_POST["status_meja"]);
    

    if ($id_meja != '' and $no_meja != '' and $status_meja != '') {

        // Create connection
        $koneksi = new mysqli($servername, $usernamedb, $passworddb, $dbname);
        // Check connection
        if ($koneksi->connect_error) {
            die("Connection failed: " . $koneksi->connect_error);
        }
        
        
        $sql = "UPDATE meja SET id_meja='$id_meja', no_meja='$no_meja', status_meja='$status_meja' WHERE id_meja='$id_meja'";

        if (mysqli_query($koneksi, $sql)) {
            header('location:../meja.php');
           
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
        }
        $koneksi->close();
    }
}