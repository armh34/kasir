
<?php
// Start the session
session_start();

$servername = "localhost";
$usernamedb = "root";
$passworddb = "";
$dbname = "coba_ukk";

//--filter input
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}



// define variables and set to empty values
if ($_SERVER["REQUEST_METHOD"] == "POST")  {
    $nama = test_input($_POST["nama"]);
    $username = test_input($_POST["username"]);
    $password = test_input($_POST["password"]);
    $level = test_input($_POST["level"]);


    if ($nama  != '' and $username != '') {

        // Create connection
        $koneksi = new mysqli($servername, $usernamedb, $passworddb, $dbname);
        // Check connection
        if ($koneksi->connect_error) {
            die("Connection failed: " . $koneksi->connect_error);
        }

        $sql = "INSERT INTO user (nama, username, password, level)
        VALUES ('$nama', '$username', '$password', '$level')";

        if (mysqli_query($koneksi, $sql)) {
            header('location:../user.php');
            
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
        }
        $koneksi->close();
    }
}
