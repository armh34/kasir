<?php
// Start the session
session_start();

$servername = "localhost";
$usernamedb = "root";
$passworddb = "";
$dbname = "coba_ukk";

//--filter input
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//var_dump(isset($_POST['proses']));die;

// define variables and set to empty values

if (isset($_POST['proses'])) {
    //var_dump("oke");die;
    $id_user = test_input($_POST["id_user"]);
    $nama = test_input($_POST["nama"]);
    $username = test_input($_POST["username"]);
    $password = test_input($_POST["password"]);
    $level = test_input($_POST["level"]);


    if ($id_user != '' and $nama != '' and $username != '' and $password != '' and $level !='') {

        // Create connection
        $koneksi = new mysqli($servername, $usernamedb, $passworddb, $dbname);
        // Check connection
        if ($koneksi->connect_error) {
            die("Connection failed: " . $koneksi->connect_error);
        }
        
        
        $sql = "UPDATE user SET id_user='$id_user', nama='$nama', username='$username', password='$password', level='$level' WHERE id_user='$id_user'";

        if (mysqli_query($koneksi, $sql)) {
            header('location:../user.php');
           
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
        }
        $koneksi->close();
    }
}