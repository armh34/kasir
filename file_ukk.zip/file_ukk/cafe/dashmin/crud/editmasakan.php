<?php
// Start the session
session_start();

$servername = "localhost";
$usernamedb = "root";
$passworddb = "";
$dbname = "coba_ukk";

//--filter input
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//var_dump(isset($_POST['proses']));die;

// define variables and set to empty values

if (isset($_POST['proses'])) {
    //var_dump("oke");die;
    $id_masakan = test_input($_POST["id_masakan"]);
    $nama_masakan = test_input($_POST["nama_masakan"]);
    $type = test_input($_POST["type"]);
    $status_masakan = test_input($_POST["status_masakan"]);
    $harga = test_input($_POST["harga"]);


    if ($id_masakan != '' and $nama_masakan != '' and $type != '' and $status_masakan != '' and $harga !='') {

        // Create connection
        $koneksi = new mysqli($servername, $usernamedb, $passworddb, $dbname);
        // Check connection
        if ($koneksi->connect_error) {
            die("Connection failed: " . $koneksi->connect_error);
        }
        
        
        $sql = "UPDATE masakan SET id_masakan='$id_masakan', nama_masakan='$nama_masakan', type='$type', status_masakan='$status_masakan', harga='$harga' WHERE id_masakan='$id_masakan'";

        if (mysqli_query($koneksi, $sql)) {
            header('location:../masakan.php');
           
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
        }
        $koneksi->close();
    }
}